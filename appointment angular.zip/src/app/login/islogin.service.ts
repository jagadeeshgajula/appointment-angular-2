import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IsloginService {
  subject = new BehaviorSubject<any>(undefined)
  
  constructor() {
    
   }
  
  setSubject(flag){
    this.subject.next(flag);
  }

  getSubject(){
    return this.subject.asObservable();
  }

  checkIsUserLogin()
  {
    var flag = (localStorage.getItem('uid') != null && localStorage.getItem('uid') != undefined)?true:false
    this.setSubject(flag);
  }
  
}
